package com.example.blackmarket.POJOS;

public class TempID {
    int n;

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }
}
