package com.example.blackmarket.POJOS;

public class Producto_Cant {
    //Producto productID;
    int cantidad;

   /* public Producto getProductID() {
        return productID;
    }

    public void setProductID(Producto productID) {
        this.productID = productID;
    }*/

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
