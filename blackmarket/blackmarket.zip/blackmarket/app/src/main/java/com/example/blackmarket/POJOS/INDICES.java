package com.example.blackmarket.POJOS;

public class INDICES {
    int direccionSeleccionada;

    public int getDireccionSeleccionada() {
        return direccionSeleccionada;
    }

    public void setDireccionSeleccionada(int direccionSeleccionada) {
        this.direccionSeleccionada = direccionSeleccionada;
    }
}
