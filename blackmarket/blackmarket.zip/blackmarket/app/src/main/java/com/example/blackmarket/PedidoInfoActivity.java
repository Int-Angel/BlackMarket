package com.example.blackmarket;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.blackmarket.Adapters.Adaptador_PedidoInfo;

import org.w3c.dom.Text;

public class PedidoInfoActivity extends AppCompatActivity {
    RecyclerView ListaPedidoInfo;
    TextView pedidoTotal, nombre, direccion, cp, fecha;
    Button cancelar;
    int indice, PedID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido_info);

        indice = getIntent().getIntExtra("indice",-1);
        PedID = getIntent().getIntExtra("PedID", -1);

        pedidoTotal = findViewById(R.id.pedido_info_total);
        ListaPedidoInfo = findViewById(R.id.Lista_pedido_info);
        cancelar = findViewById(R.id.pedido_info_cancelar_boton);
        nombre = findViewById(R.id.pedido_info_nombre);
        direccion = findViewById(R.id.pedido_info_direccion);
        cp = findViewById(R.id.pedido_info_cp);
        fecha = findViewById(R.id.pedido_info_fecha);

        nombre.setText(GLOBAL.USUARIO.getNombre() + " "+ GLOBAL.USUARIO.getApellidos());
        direccion.setText(GLOBAL.DIRECCIONS.get(GLOBAL.PEDIDO.get(indice).getIdx_dir()).getDireccion());
        cp.setText(GLOBAL.DIRECCIONS.get(GLOBAL.PEDIDO.get(indice).getIdx_dir()).getCp());
        fecha.setText(GLOBAL.PEDIDO.get(indice).getFecha());

        Adaptador_PedidoInfo api = new Adaptador_PedidoInfo();
        api.context = this;
        api.indx = indice;
        api.PedID = PedID;
        LinearLayoutManager llm = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        ListaPedidoInfo.setLayoutManager(llm);
        ListaPedidoInfo.setAdapter(api);

        pedidoTotal.setText("$"+GLOBAL.PEDIDO.get(indice).getTotal());

        if(GLOBAL.PEDIDO.get(indice).getStatus() == 3){
            cancelar.setVisibility(View.GONE);
        }

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelarPedido();
            }
        });
    }



    public void Atras(View view) {
        onBackPressed();
    }

    public void cancelarPedido(){
        GLOBAL.PEDIDO.remove(indice);

        Intent intent = new Intent(this, VerPedidosActivity.class);
        intent.putExtra("car",true);
        startActivity(intent);
        finish();
    }
}
