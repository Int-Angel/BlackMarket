package com.example.blackmarket.POJOS;

import java.util.ArrayList;

public class DescripcionPedido {
    int DescPedidoID;
    int PedID;
    ArrayList<Producto> Productos = new ArrayList<>();

}

